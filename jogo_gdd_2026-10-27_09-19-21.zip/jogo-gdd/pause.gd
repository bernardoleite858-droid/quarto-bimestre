
extends CanvasLayer

@onready var painel_pause: Control = $PainelPause

@onready var botao_continuar: Button = $PainelPause/Centro/Botoes/Continuar
@onready var botao_reiniciar: Button = $PainelPause/Centro/Botoes/Reiniciar
@onready var botao_sair: Button = $PainelPause/Centro/Botoes/Sair

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	painel_pause.hide()

	botao_continuar.pressed.connect(continuar)
	botao_reiniciar.pressed.connect(reiniciar)
	botao_sair.pressed.connect(sair)

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel") and not event.is_echo():
		alternar_pausa()
		get_viewport().set_input_as_handled()

func alternar_pausa() -> void:
	if get_tree().paused:
		continuar()
	else:
		painel_pause.show()
		get_tree().paused = true

func continuar() -> void:
	get_tree().paused = false
	painel_pause.hide()

func reiniciar() -> void:
	get_tree().paused = false
	get_tree().reload_current_scene()

func sair() -> void:
	get_tree().paused = false
	get_tree().change_scene_to_file("res://menu_principal.tscn")
