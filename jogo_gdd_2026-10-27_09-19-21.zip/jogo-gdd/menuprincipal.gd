
extends Control

func _ready():
	$CenterContainer/VBoxContainer/BotaoJogar.pressed.connect(_on_jogar_pressed)
	$CenterContainer/VBoxContainer/BotaoSair.pressed.connect(_on_sair_pressed)

func _on_jogar_pressed():
	get_tree().change_scene_to_file("res://cenario.tscn")

func _on_opcoes_pressed():
	print("Abrir opções")

func _on_sair_pressed():
	get_tree().quit()
