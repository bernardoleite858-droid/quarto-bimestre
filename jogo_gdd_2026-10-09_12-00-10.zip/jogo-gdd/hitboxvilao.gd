extends Area2D


# Quantidade de dano que este inimigo causa ao encostar
@export var dano: int = 100

func get_dano() -> int:
	return dano
