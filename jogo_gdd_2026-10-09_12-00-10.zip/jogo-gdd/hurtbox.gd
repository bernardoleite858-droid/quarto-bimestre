class_name Hurtbox
extends Area2D

signal damage_received(amount: int, knockback: Vector2)

func take_damage(amount: int) -> void:
	damage_received.emit(amount)
