extends CanvasLayer

const CENARIO = preload("res://cenario.tscn")

func _on_play_pressed() -> void:
	get_tree().change_scene_to_packed(CENARIO)
