extends CharacterBody2D

@export var speed: float = 100.0
@export var damage: int = 10

var direction: int = 1
var gravity: float = ProjectSettings.get_setting("physics/2d/default_gravity")

func _physics_process(delta: float) -> void:
	# Aplica a gravidade se o inimigo não estiver no chão
	if not is_on_floor():
		velocity.y += gravity * delta

	# Se colidir com uma parede, inverte a direção da patrulha
	if is_on_wall():
		direction *= -1

	# Define a velocidade horizontal e aplica o movimento
	velocity.x = direction * speed
	move_and_slide()

# Conecte o sinal "body_entered" do nó Hitbox (Area2D) a esta função
func _on_hitbox_body_entered(body: Node2D) -> void:
	if body.is_in_group("Player") and body.has_method("take_damage"):
		body.take_damage(damage)
