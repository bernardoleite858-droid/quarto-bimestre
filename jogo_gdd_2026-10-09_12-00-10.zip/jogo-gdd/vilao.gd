

extends CharacterBody2D

var velocidade: float = 100.0
var dano: int = 10
var intervalo_dano: float = 1.0

# Direção do movimento: 1 = Direita, -1 = Esquerda
var direcao: float = 1.0



var gravidade: float = ProjectSettings.get_setting("physics/2d/default_gravity")
var tempo_ultimo_dano: float = 0.0

func _physics_process(delta: float) -> void:
	tempo_ultimo_dano += delta

	# Aplica gravidade
	if not is_on_floor():
		velocity.y += gravidade * delta

	# Se colidir com uma parede, inverte o sentido
	if is_on_wall():
		direcao *= -1.0
	if not $RayCast2D.is_colliding():
		direcao *= -1.0 # Inverte a direção (1 vira -1, -1 vira 1)

	# Mantém a caminhada contínua na direção atual
	velocity.x = direcao * velocidade

	move_and_slide()
	
