
class_name Hitbox
extends Area2D

signal hit_registered(hurtbox: Hurtbox)
@export var damage: int = 1


func _ready() -> void:
	self.area_entered.connect(_on_area_entered)

func _on_area_entered(area: Area2D) -> void:
	if area is Hurtbox:
		var direction: float = sign(area.global_position.x - global_position.x)
		
		if direction == 0:
			direction = 1.0
			
		area.take_damage(damage)
		hit_registered.emit(area)
